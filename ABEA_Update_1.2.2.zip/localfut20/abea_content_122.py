"""ABEA FUT20 1.2.2: optional Gold Pack and native Upgrade SBC rewards.

No database migrations, authentication edits or modifications to game executables.
This module is loaded from the existing October POTM addon after runtime initialization.
"""
from __future__ import annotations
import json
import random
import time

GOLD_PACK_ID = 72
GOLD_PACK_PRICE = 10000
GOLD_PACK_CONFIG = {
    'enabled': True, 'name': 'ABEA 10K Gold Mixed Pack',
    'bio': '6 Rare Gold players, 3 Common Gold players, 1 manager and 1 position modifier.',
    'price': GOLD_PACK_PRICE, 'size': 11, 'rare_slots': 6,
    'min_rating': 75, 'pack_asset_id': 3, 'store_group': 'gold',
    'content_type': 'mixed', 'kind': 'abea_mixed_gold_10k',
}
# Original FIFA 20 server packs (keep original native pack generators).
UPGRADE_REWARDS = {
    3001: (9, 'Jumbo Premium Bronze Pack'),
    3101: (11, 'Jumbo Premium Silver Pack'),
    3201: (1010, 'Two Rare Gold Players Pack'),
}


def _integer(value, default=0):
    try: return int(value)
    except (ValueError, TypeError): return default


def _is_safe_gold(meta):
    if not isinstance(meta, dict) or _integer(meta.get('resourceId')) <= 0:
        return False
    if _integer(meta.get('rating')) < 75:
        return False
    rarity = str(meta.get('rarityName') or '').casefold()
    if any(s in rarity for s in ('tots','totw','sbc','objective','potm','icon','hero',
                                  'flashback','moments','storyline','scream','futmas','special')):
        return False
    tier = str(meta.get('tier') or '').casefold()
    return tier == 'gold' or (not tier and _integer(meta.get('rating')) >= 75)


def _split_player_pools(db):
    rare,common=[],[]
    for meta in db.values():
        if not _is_safe_gold(meta): continue
        rid=_integer(meta.get('resourceId'))
        rarity=str(meta.get('rarityName') or '').casefold()
        flag=_integer(meta.get('rareflag'), 0)
        special=bool(meta.get('special'))
        if special:continue
        if ('non-rare' in rarity or 'non rare' in rarity or 'common' in rarity or
            (flag==0 and 'rare' not in rarity)):
            common.append(rid)
        elif 'rare' in rarity or flag==1:
            rare.append(rid)
    return sorted(set(rare)),sorted(set(common))


def _pick_position_modifier(db):
    # Position-modifier consumables are classified by the original game resource.
    valid=[]
    for key, meta in db.items():
        if not isinstance(meta,dict):continue
        src=str(meta.get('sourceMember') or '').casefold()
        if 'consumablesposition' in src or 'positionmodifier' in src:
            rid=_integer(meta.get('resourceId') or key)
            if rid>0:valid.append(rid)
    return sorted(set(valid))


def _make_mixed_pack(state, pool, manager_pool, positions, *, rng=None):
    """Store real native player/manager/consumable items, preserving dupes."""
    rand=rng or random.SystemRandom()
    # Sample separately, so the promised six rare + three common is guaranteed.
    rare=rand.sample(pool[0],6)
    commons=rand.sample(pool[1],3)
    manager=rand.choice(manager_pool)
    position=rand.choice(positions)
    from localfut20 import abdullah_v12 as base
    owned_before=set(_integer(x) for x in state.owned_player_resource_ids())
    ownership={}
    for pile in ('club','squad'):
        for item in state.list_items(pile):
            if isinstance(item,dict) and str(item.get('itemType') or 'player').lower()=='player':
                rid=_integer(item.get('resourceId') or item.get('assetId'))
                iid=_integer(item.get('id'))
                if rid>0 and iid>0:ownership.setdefault(rid,iid)
    created=[]
    try:
        for rid in rare + commons:
            created.append(state.make_player_item(rid, 'unassigned'))
        created.append(state.make_manager_item(manager, 'unassigned'))
        created.append(state.make_consumable_item(position, 'unassigned'))
        if len(created)!=11 or not all(isinstance(x,dict) and _integer(x.get('id'))>0 for x in created):
            raise RuntimeError('ABEA 10K pack could not persist all 11 items.')
        # Keep nine players first in the same ordering used by existing V1.2 packs.
        players=sorted(created[:9],key=base._native_item_order)
        items=players+created[9:]
        stamp=int(time.time())
        with state.lock:
            with state.conn:
                for rank,item in enumerate(items):
                    item['timestamp']=stamp-rank
                    state.conn.execute('UPDATE items SET data=? WHERE id=?',
                                       (json.dumps(item),_integer(item['id'])))
        dupes=[]
        for item in players:
            rid=_integer(item.get('resourceId'))
            if rid not in owned_before:continue
            iid=_integer(item['id']);state.mark_item_duplicate(iid,True)
            d={'itemId':iid}
            if rid in ownership:d['duplicateItemId']=ownership[rid]
            dupes.append(d)
        if dupes:
            refreshed={_integer(x.get('id')):x for x in state.list_items('unassigned') if isinstance(x,dict)}
            items=[refreshed.get(_integer(item['id']),item) for item in items]
        return {'packId':GOLD_PACK_ID,'purchasedPackId':GOLD_PACK_ID,'packType':'GOLD',
                'itemList':items,'itemData':items,'items':items,
                'newcards':11-len(dupes),'numberItems':11,
                'duplicateItemIdList':dupes,'credits':state.credits()}
    except Exception:
        # Do not leave a half-created pack in New Items if an underlying method fails.
        for item in created:
            if isinstance(item,dict) and _integer(item.get('id'))>0:
                try:state.delete_item(_integer(item['id']))
                except Exception:pass
        raise


def install_abea_122(g):
    if g.get('_abea_content_122_installed'):return
    from localfut20 import abdullah_v12 as base
    if GOLD_PACK_ID in base.PACKS:
        raise RuntimeError('ABEA 1.2.2 pack ID 72 already taken: refusing overwrite')
    for key in ('STATE','State','PLAYER_DB','SBC_CATALOG','CHALLENGE_BY_ID',
                'MANAGER_DB','CONSUMABLE_DB','_store_purchasegroups','get_pack_cfg','log'):
        if key not in g:raise RuntimeError('ABEA 1.2.2 missing runtime API: '+key)

    # Do not install until we know the native pack definitions are really present.
    for challenge_id,(pack_id,_) in UPGRADE_REWARDS.items():
        if challenge_id not in g['CHALLENGE_BY_ID']:
            raise RuntimeError(f'ABEA 1.2.2 missing upgrade SBC {challenge_id}')
        if not g['get_pack_cfg'](pack_id):
            raise RuntimeError(f'ABEA 1.2.2 missing native reward pack {pack_id}')
    rare,common=_split_player_pools(g['PLAYER_DB'])
    managers=sorted(set(_integer(v.get('resourceId') or k) for k,v in g['MANAGER_DB'].items()
                        if isinstance(v,dict) and _integer(v.get('resourceId') or k)>0))
    positions=_pick_position_modifier(g['CONSUMABLE_DB'])
    if len(rare)<6 or len(common)<3 or not managers or not positions:
        # Missing real resources: other features should keep working; leave Gold
        # 10K pack unavailable rather than falsely advertising its contents.
        g['log'].warning('ABEA 1.2.2 mixed 10K pack disabled (rare=%s common=%s managers=%s position=%s)',
                         len(rare),len(common),len(managers),len(positions))
        mixed_ready=False
    else:mixed_ready=True

    for cid,(pack_id,pack_name) in UPGRADE_REWARDS.items():
        entry,challenge=g['CHALLENGE_BY_ID'][cid]
        challenge['awards']=[{'type':'PACK','pack_id':pack_id,'count':1}]
        entry['description']=('Exchange Bronze players for a Jumbo Premium Bronze Pack.' if cid==3001 else
                              'Exchange Silver players for a Jumbo Premium Silver Pack.' if cid==3101 else
                              'Exchange Gold players for a Two Rare Gold Players Pack.')
        g['log'].info('ABEA 1.2.2 Upgrade SBC %s -> reward pack %s (%s)',cid,pack_id,pack_name)
    if mixed_ready:
        base.PACKS[GOLD_PACK_ID]=dict(GOLD_PACK_CONFIG)
        old_create=g['State'].create_pack
        def create_pack(self,pack_id):
            if _integer(pack_id)==GOLD_PACK_ID:
                return _make_mixed_pack(self,(rare,common),managers,positions)
            return old_create(self,pack_id)
        g['State'].create_pack=create_pack
        old_store=g['_store_purchasegroups']
        def store():
            result=old_store()
            if not isinstance(result,dict):return result
            rows=list(result.get('purchase') or [])
            if any(isinstance(r,dict) and _integer(r.get('packId') or r.get('id'))==GOLD_PACK_ID for r in rows):return result
            row=base._store_entry(GOLD_PACK_ID,GOLD_PACK_CONFIG)
            row.update({'purchaseGroup':'gold','group':'gold','isPromo':False,
                        'packType':'GOLD','displayGroup':{'value':'gold','priority':2},
                        'categoryList':{'categoryId':2,'orderInCategory':GOLD_PACK_ID}})
            row['packContentInfo']={'itemQuantity':11,'goldQuantity':9,'silverQuantity':0,
                                    'bronzeQuantity':0,'rareQuantity':6,
                                    'playersQuantity':9,'managerQuantity':1,'consumableQuantity':1}
            rows.append(row)
            out=dict(result);out['purchase']=rows
            return out
        g['_store_purchasegroups']=store
    g['_abea_content_122_installed']=True
    g['log'].info('ABEA 1.2.2 installed: Upgrade rewards and 10K Gold mixed pack ready=%s',mixed_ready)
