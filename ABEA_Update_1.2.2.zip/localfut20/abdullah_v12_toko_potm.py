"""FIFA 20 local: October 2019 LaLiga POTM Toko-Ekambi (86 ST).

Adds a 4-segment, non-repeatable SBC to working V1.2 without changing existing
packs, seasonal objectives, launcher, runtime or saved accounts. Local-only.
"""
from __future__ import annotations
import json
import time

POTM_RESOURCE_ID = 84110149
POTM_ASSET_ID = 224069
SBC_SET_ID = 9700
CHALLENGES = (9701, 9702, 9703, 9704)
TWO_RARE_PLAYERS_PACK_ID = 70

PACK_CONFIG = {
    'enabled': True, 'reward_only': True,
    'name': 'Two Rare Gold Players Pack (SBC Reward)',
    'bio': 'Two rare Gold player items from the local player database.',
    'price': 0, 'size': 2, 'rare_slots': 2,
    'min_rating': 75, 'pack_asset_id': 4,
    'store_group': 'mypacks', 'kind': 'rating',
}


# Reward-only, guaranteed one-player pack. Do NOT sell this in the regular store.
# Native State.complete_sbc supports PACK and COINS, but silently skips PLAYER.
POTM_FINAL_PACK_ID = 71
POTM_FINAL_PACK_CONFIG = {
    'enabled': True, 'reward_only': True,
    'name': 'Toko-Ekambi POTM 86 Guaranteed Pack',
    'bio': 'Contains exactly one Toko-Ekambi October 2019 LaLiga POTM 86 player.',
    'price': 0, 'size': 1, 'rare_slots': 1,
    'min_rating': 86, 'pack_asset_id': 4,
    'store_group': 'mypacks', 'kind': 'potm_guaranteed',
}


def _int(v, fallback=0):
    try:
        return int(v)
    except (ValueError, TypeError):
        return fallback


def _find_potm(g):
    db = g['PLAYER_DB']
    direct = db.get(str(POTM_RESOURCE_ID)) or db.get(POTM_RESOURCE_ID)
    if (isinstance(direct, dict) and _int(direct.get('rating')) == 86 and
        _int(direct.get('assetId') or direct.get('assetid')) in (0,POTM_ASSET_ID) and
        any(x in str(direct.get('rarityName') or direct.get('rarity') or '').lower()
            for x in ('potm','player of the month'))):
        return POTM_RESOURCE_ID
    possible = []
    for meta in db.values():
        if not isinstance(meta, dict):
            continue
        if _int(meta.get('assetId') or meta.get('assetid')) != POTM_ASSET_ID:
            continue
        if _int(meta.get('rating')) != 86:
            continue
        rarity = str(meta.get('rarityName') or meta.get('rarity') or '').lower()
        if any(x in rarity for x in ('potm','player of the month')):
            possible.append(_int(meta.get('resourceId')))
    possible = list(set(x for x in possible if x>0))
    if len(possible) == 1:
        return possible[0]
    raise RuntimeError('Toko-Ekambi October POTM 86 is missing/ambiguous in PLAYER_DB; no wrong card will be awarded')


def _totw_count(g, item_ids):
    count = 0
    for iid in item_ids:
        row = g['STATE'].get_item(iid)
        if not isinstance(row,dict):
            continue
        rid = _int(row.get('resourceId'))
        meta = g['PLAYER_DB'].get(str(rid)) or g['PLAYER_DB'].get(rid) or {}
        rarity = str(meta.get('rarityName') or '').lower().strip()
        if rarity in ('team of the week','totw moments') or 'team of the week' in rarity:
            count += 1
    return count


def _rules(rating, *, totw=False, chemistry=None):
    rules = [
        {'kind':'player_count','value':11,'scope':'exact','count':-1,
         'text':'Players in the Squad: Exactly 11'},
        {'kind':'team_rating','value':int(rating),'scope':'min','count':-1,
         'text':f'Team Overall Rating: Min. {rating}'},
    ]
    if totw:
        # Older client reports 'rare_count' to SBC evaluator; our server-side
        # override verifies the card really is TOTW, not just a rare player.
        rules.append({'kind':'rare_count','value':1,'scope':'min','count':-1,
                      'text':'TOTW Players: Min. 1'})
    if chemistry is not None:
        rules.append({'kind':'chemistry','value':int(chemistry),'scope':'min','count':-1,
                      'text':f'Team Chemistry: Min. {chemistry}'})
    return rules


def _rare_gold_pool(db):
    rows=[]
    for meta in db.values():
        if not isinstance(meta,dict):
            continue
        rid=_int(meta.get('resourceId'))
        if rid<=0 or _int(meta.get('rating')) < 75:
            continue
        rarity=str(meta.get('rarityName') or '').lower()
        tier=str(meta.get('tier') or '').lower()
        if 'non-rare' in rarity or 'non rare' in rarity or 'common' in rarity:
            continue
        is_rare = ('rare' in rarity or _int(meta.get('rareflag'))==1)
        if is_rare and (tier=='gold' or _int(meta.get('rating'))>=75):
            rows.append(rid)
    return sorted(set(rows))


def install_toko_potm(g):
    if g.get('_abdullah_v12_toko_enabled'):
        return
    required=('STATE','State','PLAYER_DB','SBC_CATALOG','SET_BY_ID','CHALLENGE_BY_ID',
              '_sbc_evaluate','_sbc_set_summary','_store_purchasegroups',
              'load_pack_settings','get_pack_cfg','_sbc_awards_payload')
    for key in required:
        if key not in g:
            raise RuntimeError('Missing V1.2 runtime API: '+key)
    from localfut20 import abdullah_v12 as base
    rid = _find_potm(g)
    pool = _rare_gold_pool(g['PLAYER_DB'])
    if len(pool) < 2:
        raise RuntimeError('Two Rare Gold Players Pack cannot find 2 rare Gold players')
    if SBC_SET_ID in g['SET_BY_ID'] or any(cid in g['CHALLENGE_BY_ID'] for cid in CHALLENGES):
        raise RuntimeError('POTM SBC IDs conflict with an existing challenge; no changes made')
    if TWO_RARE_PLAYERS_PACK_ID in base.PACKS or POTM_FINAL_PACK_ID in base.PACKS:
        raise RuntimeError('Toko reward pack ID 70 or 71 already used; refusing to overwrite it')
    # The V1.2 config loader uses the shared PACKS mapping on demand.
    # Native SBC reward validation will therefore recognize both pack IDs.
    base.PACKS[TWO_RARE_PLAYERS_PACK_ID] = dict(PACK_CONFIG)
    base.PACKS[POTM_FINAL_PACK_ID] = dict(POTM_FINAL_PACK_CONFIG)
    if not callable(g.get('get_pack_cfg')) or not g['get_pack_cfg'](POTM_FINAL_PACK_ID):
        raise RuntimeError('POTM pack 71 not recognized by native reward config; stop safely')

    ch=[]
    spec=((9701,82,False,None),(9702,82,False,None),
          (9703,83,True,None),(9704,85,False,55))
    for cid,rating,totw,chem in spec:
        rules=_rules(rating,totw=totw,chemistry=chem)
        ch.append({'challenge_id':cid,
                   'name':f'{rating} Rated Squad'+(' + TOTW' if totw else '')+
                          (' | 55 Chemistry' if chem is not None else ''),
                   'description':('11 players. '+f'Minimum rating {rating}. '+
                                  ('Requires one TOTW (Inform). ' if totw else '')+
                                  ('Minimum 55 Chemistry. ' if chem is not None else '')),
                   'players':11,'formation':'f442', 'rules':rules,
                   # Every segment must expose a reward to this FIFA20 client.
                   # Preserve the two rare-player packs for both 82 squads;
                   # both 83+TOTW and 85+55 chemistry receive native 7,500 packs.
                   'awards':[{'type':'PACK','pack_id':(
                       TWO_RARE_PLAYERS_PACK_ID if cid in (9701,9702) else 12),
                       'count':1}]})
    entry={'set_id':SBC_SET_ID,'category_id':3,'category':'UPGRADES','priority':5,
           'name':'October 2019 LaLiga POTM - Toko-Ekambi 86',
           'description':'Complete 82,82,83+TOTW,85+55 chemistry to earn a guaranteed Toko-Ekambi POTM 86 pack.',
           'repeatable':False,
           # Native PACK award is persisted atomically with the final completed
           # squad. The guaranteed POTM card is created only on opening it.
           'awards':[{'type':'PACK','pack_id':POTM_FINAL_PACK_ID,'count':1}], 'challenges':ch}
    g['SBC_CATALOG'].append(entry)
    g['SET_BY_ID'][SBC_SET_ID]=entry
    for c in ch:
        g['CHALLENGE_BY_ID'][int(c['challenge_id'])]=(entry,c)

    previous_eval=g['_sbc_evaluate']
    def evaluate(challenge, saved):
        valid,checks,items=previous_eval(challenge,saved)
        if _int(challenge.get('challenge_id'))==9704:
            # Diagnostic for the 85-rated / 55-chemistry final segment.
            # Never bypass the native requirements or award a card on a failed submit.
            g['log'].info('TOKO 9704 VALIDATION valid=%s players=%s checks=%s',
                          valid,len(items),[(str(c.get('type')),bool(c.get('valid')),
                                            _int(c.get('actual')),_int(c.get('target')))
                                           for c in checks])
        if _int(challenge.get('challenge_id'))!=9703:
            return valid,checks,items
        totw=_totw_count(g,items)
        adjusted=[]
        for c in checks:
            copy=dict(c)
            if copy.get('type')=='rare_count':
                copy.update({'actual':totw,'valid':totw>=1,
                             'description':'TOTW Players: Min. 1'})
            adjusted.append(copy)
        return bool(len(items)==11 and totw>=1 and all(c.get('valid',False) for c in adjusted)),adjusted,items
    g['_sbc_evaluate']=evaluate

    previous_create=g['State'].create_pack
    def create_pack(self,pack_id):
        ident=_int(pack_id)
        if ident == POTM_FINAL_PACK_ID:
            # One card, and only the exact POTM resource ID resolved above.
            # The native-like pack generator handles order and duplicates.
            return base._make_pack(self, POTM_FINAL_PACK_ID, [rid])
        if ident == TWO_RARE_PLAYERS_PACK_ID:
            return base._make_pack(self, TWO_RARE_PLAYERS_PACK_ID, pool)
        return previous_create(self,pack_id)
    g['State'].create_pack=create_pack

    previous_store=g['_store_purchasegroups']
    def store():
        result=previous_store()
        if not isinstance(result,dict):
            return result
        counts=g['STATE'].unopened_pack_counts()
        rows=list(result.get('purchase') or [])
        for pack_id, config in ((TWO_RARE_PLAYERS_PACK_ID, PACK_CONFIG),
                                (POTM_FINAL_PACK_ID, POTM_FINAL_PACK_CONFIG)):
            qty=_int(counts.get(pack_id, counts.get(str(pack_id),0)))
            if qty<=0: continue
            if any(isinstance(row,dict) and _int(row.get('packId') or row.get('id'))==pack_id
                   for row in rows): continue
            rows.append(base._store_entry(pack_id,config,quantity=qty,is_reward=True))
        out=dict(result)
        out['purchase']=rows
        return out
    g['_store_purchasegroups']=store

    previous_summary=g['_sbc_set_summary']
    def summary(e,challenge_counts,set_counts):
        info=previous_summary(e,challenge_counts,set_counts)
        if _int(e.get('set_id'))==SBC_SET_ID and isinstance(info,dict):
            counts,sets=g['STATE'].sbc_completion_counts()
            info.update({'challengesCount':4,
                         'challengesCompletedCount':sum(_int(counts.get(cid))>0 for cid in CHALLENGES),
                         'timesCompleted':_int(sets.get(SBC_SET_ID))})
        return info
    g['_sbc_set_summary']=summary

    previous_complete=g['State'].complete_sbc
    def complete(self,challenge_id,set_id,item_ids,challenge_awards,
                 set_challenge_ids,set_awards,repeatable):
        result=previous_complete(self,challenge_id,set_id,item_ids,challenge_awards,
                                 set_challenge_ids,set_awards,repeatable)
        if _int(set_id)==SBC_SET_ID and isinstance(result,dict):
            progress,sets=self.sbc_completion_counts()
            done=sum(_int(progress.get(cid))>0 for cid in CHALLENGES)
            result.update({'challengesCount':4,'challengesCompletedCount':done,
                           'setCompleted':_int(sets.get(SBC_SET_ID))>0})
            g['log'].info('Toko-Ekambi POTM SBC progress %s/4, guaranteed pack when set completes=%s',
                          done, bool(result['setCompleted']))
        return result
    g['State'].complete_sbc=complete

    # Diagnostic only: track whether the real client SUBMITTED or only SAVED
    # an SBC squad. The original route owns validation, item consumption and
    # rewards. We do not synthesize a submission or silently award cards.
    previous_route=g['route_fut']
    import re
    from urllib.parse import urlsplit
    def toko_route(method, raw_path, headers, body):
        path=urlsplit(str(raw_path)).path.lower().rstrip('/')
        m=re.search(r'/sbs/(?:challenge|challenges|squad|squads)/(970[1-4])(?:/|$)', path)
        if not m:
            return previous_route(method,raw_path,headers,body)
        cid=int(m.group(1))
        before,_=g['STATE'].sbc_completion_counts()
        response=previous_route(method,raw_path,headers,body)
        after,_=g['STATE'].sbc_completion_counts()
        status=response[0] if isinstance(response,tuple) and response else 'unknown'
        g['log'].info('TOKO V12 ROUTE %s %s HTTP=%s completion_before=%s completion_after=%s',
                      str(method).upper(),path,status,_int(before.get(cid)),_int(after.get(cid)))
        return response
    g['route_fut']=toko_route

    # Never run the old direct player grant, even when a set was completed in
    # a prior version. Its receipt remains untouched to prevent lost history.
    # Apply independent ABEA update 1.2.2 after October POTM is registered.
    from localfut20.abea_content_122 import install_abea_122
    install_abea_122(g)
    g['_abdullah_v12_toko_enabled']=True
    g['log'].info('October POTM Toko-Ekambi 86 SBC installed (4 squads; 82: rare duo, 83+85: 7500, final guaranteed POTM pack)')
