"""ABEA 20 FUT local update 1.2.3.

Compatibility module name and entry function remain unchanged so the current
Toko adapter can still load this plugin.  New 10K pack advertises itself only
when the live runtime exposes all required native card resources/factories.
Never manufactures substitute player cards in place of badges, kits or styles.
"""
from __future__ import annotations
import json
import random
import time

GOLD_PACK_ID=72
GOLD_PACK_PRICE=10_000
GOLD_PACK_CONFIG={
    'enabled':True,
    'name':'ABEA 10K Rare Gold Essentials Pack',
    'bio':'12 items: 6 Rare Gold players (one 81+ guaranteed), 2 Chemistry Styles, 2 Position Modifiers, 1 Club Badge, 1 Kit.',
    'price':GOLD_PACK_PRICE,'size':12,'rare_slots':6,
    'min_rating':75,'pack_asset_id':3,'store_group':'gold',
    'content_type':'mixed','kind':'abea_mixed_gold_10k',
}
UPGRADE_REWARDS={
    3001:(9,'Jumbo Premium Bronze Pack','bronze'),
    3101:(11,'Jumbo Premium Silver Pack','silver'),
    3201:(1010,'Two Rare Gold Players Pack','gold'),
}


def _int(x,default=0):
    try:return int(x)
    except (ValueError,TypeError):return default


def _safe_gold(meta):
    if not isinstance(meta,dict) or _int(meta.get('resourceId'))<=0 or _int(meta.get('rating'))<75:
        return False
    rarity=str(meta.get('rarityName') or '').casefold()
    if meta.get('special') or any(w in rarity for w in (
        'tots','totw','team of the week','team of the season','sbc','objective',
        'potm','icon','hero','flashback','moments','storyline','scream','futmas','special')):
        return False
    tier=str(meta.get('tier') or '').casefold()
    return tier=='gold' or (not tier and _int(meta.get('rating'))>=75)


def _player_pools(db):
    rare,common,high=set(),set(),set()
    for meta in db.values():
        if not _safe_gold(meta):continue
        rid=_int(meta.get('resourceId'))
        name=str(meta.get('rarityName') or '').casefold()
        flag=_int(meta.get('rareflag'))
        if any(x in name for x in ('non rare','non-rare','common')) or (flag==0 and 'rare' not in name):
            common.add(rid)
        elif 'rare' in name or flag==1:
            rare.add(rid)
            if _int(meta.get('rating'))>=81:high.add(rid)
    return sorted(rare),sorted(common),sorted(high)


def _resource_ids(db,rule):
    if not isinstance(db,dict):return []
    result=set()
    for key,meta in db.items():
        if not isinstance(meta,dict):continue
        rid=_int(meta.get('resourceId') or key)
        if rid>0 and rule(meta):result.add(rid)
    return sorted(result)


def _tag(meta):
    return ' '.join(str(meta.get(k) or '') for k in (
        'sourceMember','source','type','itemType','category','subCategory',
        'kind','name','displayName')).casefold()


def _position(meta):
    text=_tag(meta).replace('_','')
    return any(k in text for k in ('consumablesposition','positionmodifier','positionchange'))


def _chemstyle(meta):
    text=_tag(meta).replace('_','')
    return ('chemistry' in text and 'style' in text) or 'consumableschem' in text or 'chemstyle' in text


def _badge(meta):
    text=_tag(meta).replace('_','')
    return any(k in text for k in ('clubbadge','clubbadge','badge','clubcrest'))


def _kit(meta):
    text=_tag(meta).replace('_','')
    return any(k in text for k in ('clubkit','kititem','teamkit','jersey','kits'))


def _other_pools(g):
    consume=g.get('CONSUMABLE_DB') or {}
    cosmetics=[]
    for name in ('CLUB_ITEMS_DB','CLUB_ITEM_DB','KITS_DB','BADGES_DB',
                 'CLUB_DB','CLUB_ASSETS_DB'):
        db=g.get(name)
        if isinstance(db,dict):cosmetics.append(db)
    badges=set(_resource_ids(consume,_badge));kits=set(_resource_ids(consume,_kit))
    for db in cosmetics:
        badges.update(_resource_ids(db,_badge));kits.update(_resource_ids(db,_kit))
    # Some native asset tables are dedicated and omit a type string.
    if isinstance(g.get('BADGES_DB'),dict):
        badges.update(_resource_ids(g['BADGES_DB'],lambda _:True))
    if isinstance(g.get('KITS_DB'),dict):
        kits.update(_resource_ids(g['KITS_DB'],lambda _:True))
    return (_resource_ids(consume,_chemstyle),_resource_ids(consume,_position),
            sorted(badges),sorted(kits))


def _choose_factory(state_class,names):
    for name in names:
        if callable(getattr(state_class,name,None)):
            return name
    return None


def _factories(state_class):
    return {
        'badge':_choose_factory(state_class,('make_badge_item','make_crest_item','make_club_item')),
        'kit':_choose_factory(state_class,('make_kit_item','make_club_item')),
    }


def _create_12_pack(state,pools,*,factory_names,rng=None):
    """Create 6+2+2+1+1 original game items or fail with rollback.

    Never use consumable items as fake kit/badge cards.  The runtime must provide
    the real item factory before a 12-item pack is shown in the storefront.
    """
    from localfut20 import abdullah_v12 as base
    rand=rng or random.SystemRandom()
    rare,common,high,chem,pos,badge,kit=pools
    guaranteed=rand.choice(high)
    others=rand.sample([r for r in rare if r!=guaranteed],5)
    player_ids=[guaranteed]+others
    chem_ids=rand.sample(chem,2);pos_ids=rand.sample(pos,2)
    badge_id=rand.choice(badge);kit_id=rand.choice(kit)

    owned_before=set(_int(x) for x in state.owned_player_resource_ids())
    ownership={}
    for pile in ('club','squad'):
        for o in state.list_items(pile):
            if str(o.get('itemType') or 'player').lower()!='player':continue
            rid=_int(o.get('resourceId') or o.get('assetId'));iid=_int(o.get('id'))
            if rid>0 and iid>0:ownership.setdefault(rid,iid)
    created=[]
    try:
        for rid in player_ids:
            created.append(state.make_player_item(rid,'unassigned'))
        for rid in chem_ids+pos_ids:
            created.append(state.make_consumable_item(rid,'unassigned'))
        created.append(getattr(state,factory_names['badge'])(badge_id,'unassigned'))
        created.append(getattr(state,factory_names['kit'])(kit_id,'unassigned'))
        if len(created)!=12 or any(not isinstance(x,dict) or _int(x.get('id'))<=0 for x in created):
            raise RuntimeError('ABEA 10K could not persist all twelve items')
        # Never silently show a badge or kit as a position modifier.
        for obj,kind in ((created[10],'badge'),(created[11],'kit')):
            txt=str(obj.get('itemType') or obj.get('type') or '').casefold()
            if txt in ('consumable','player','manager'):
                raise RuntimeError('ABEA 10K native '+kind+' factory returned wrong item type: '+txt)
        players=sorted(created[:6],key=base._native_item_order)
        items=players+created[6:]
        stamp=int(time.time())
        with state.lock:
            with state.conn:
                for rank,item in enumerate(items):
                    item['timestamp']=stamp-rank
                    state.conn.execute('UPDATE items SET data=? WHERE id=?',
                                       (json.dumps(item),_int(item['id'])))
        dupes=[]
        for item in players:
            rid=_int(item.get('resourceId'))
            if rid not in owned_before:continue
            iid=_int(item['id']);state.mark_item_duplicate(iid,True)
            d={'itemId':iid}
            if rid in ownership:d['duplicateItemId']=ownership[rid]
            dupes.append(d)
        if dupes:
            refreshed={_int(x.get('id')):x for x in state.list_items('unassigned') if isinstance(x,dict)}
            items=[refreshed.get(_int(x['id']),x) for x in items]
        return {'packId':GOLD_PACK_ID,'purchasedPackId':GOLD_PACK_ID,'packType':'GOLD',
                'itemList':items,'itemData':items,'items':items,
                'newcards':12-len(dupes),'numberItems':12,
                'duplicateItemIdList':dupes,'credits':state.credits()}
    except Exception:
        for item in created:
            if isinstance(item,dict) and _int(item.get('id'))>0:
                try:state.delete_item(_int(item['id']))
                except Exception:pass
        raise


def _native_store_preview(g):
    """Use asset information returned for the *same pack* by the live store.

    No guessed asset constants: unsupported packs retain their existing art.
    """
    rows=(g['_store_purchasegroups']() or {}).get('purchase') or []
    result={}
    for r in rows:
        if not isinstance(r,dict):continue
        pid=_int(r.get('packId') or r.get('id'))
        if pid in (9,11,1010):
            asset=_int(r.get('packAssetId') or r.get('assetId'))
            if asset>0:result[pid]=asset
    return result


def _patch_reward_previews(g):
    original=g.get('_sbc_awards_payload')
    if not callable(original):return
    # Do not alter actual SBC awards. Preview metadata only.
    try:assets=_native_store_preview(g)
    except Exception as e:
        g['log'].warning('ABEA 1.2.3 native pack-art discovery unavailable: %s',e)
        assets={}
    g['log'].info('ABEA 1.2.3 native pack-art IDs: %s',assets)
    def rewards(awards):
        wire=original(awards)
        if not isinstance(wire,list) or not isinstance(awards,list):return wire
        for index,aw in enumerate(a for a in awards if isinstance(a,dict) and
                                  str(a.get('type') or '').upper() in ('PACK','COINS')):
            if index>=len(wire) or not isinstance(wire[index],dict):break
            pid=_int(aw.get('pack_id') or aw.get('packId') or aw.get('value'))
            if pid not in (9,11,1010):continue
            if pid in assets:
                wire[index]['packAssetId']=assets[pid]
                wire[index]['assetId']=assets[pid]
        return wire
    g['_sbc_awards_payload']=rewards


def install_abea_122(g):
    # Keep this exported name for compatibility with 1.2.2 Toko bootstrap.
    if g.get('_abea_content_122_installed'):return
    from localfut20 import abdullah_v12 as base
    if GOLD_PACK_ID in base.PACKS:
        raise RuntimeError('ABEA pack ID 72 already taken; refusing overwrite')
    required=('STATE','State','PLAYER_DB','SBC_CATALOG','CHALLENGE_BY_ID',
              'CONSUMABLE_DB','_store_purchasegroups','get_pack_cfg','log')
    for k in required:
        if k not in g:raise RuntimeError('ABEA 1.2.3 missing runtime API: '+k)
    for cid,(pid,name,_) in UPGRADE_REWARDS.items():
        if cid not in g['CHALLENGE_BY_ID'] or not g['get_pack_cfg'](pid):
            raise RuntimeError('ABEA 1.2.3 missing native upgrade '+str(cid)+' reward '+str(pid))
    rare,common,high=_player_pools(g['PLAYER_DB'])
    chem,pos,badges,kits=_other_pools(g)
    factories=_factories(g['State'])
    ready=bool(len(rare)>=6 and len(high)>=1 and len(chem)>=2 and len(pos)>=2 and
               badges and kits and all(factories.values()) and
               callable(getattr(g['State'],'make_consumable_item',None)))
    if not ready:
        g['log'].warning('ABEA 1.2.3 10K PACK DISABLED: rare=%s rare81=%s chem=%s pos=%s badges=%s kits=%s native_factories=%s',
                         len(rare),len(high),len(chem),len(pos),len(badges),len(kits),factories)
    for cid,(pid,name,_) in UPGRADE_REWARDS.items():
        entry,ch=g['CHALLENGE_BY_ID'][cid]
        ch['awards']=[{'type':'PACK','pack_id':pid,'count':1}]
        entry['description']='Exchange players to earn '+name+'.'
        g['log'].info('ABEA 1.2.3 upgrade %s -> %s (native reward)',cid,name)
    _patch_reward_previews(g)
    if ready:
        base.PACKS[GOLD_PACK_ID]=dict(GOLD_PACK_CONFIG)
        previous_create=g['State'].create_pack
        def create_pack(self,pack_id):
            if _int(pack_id)==GOLD_PACK_ID:
                return _create_12_pack(self,(rare,common,high,chem,pos,badges,kits),factory_names=factories)
            return previous_create(self,pack_id)
        g['State'].create_pack=create_pack
        previous_store=g['_store_purchasegroups']
        def store():
            src=previous_store()
            if not isinstance(src,dict):return src
            rows=list(src.get('purchase') or [])
            if any(isinstance(r,dict) and _int(r.get('packId') or r.get('id'))==GOLD_PACK_ID for r in rows):
                return src
            row=base._store_entry(GOLD_PACK_ID,GOLD_PACK_CONFIG)
            row.update({'purchaseGroup':'gold','group':'gold','isPromo':False,
                        'packType':'GOLD','displayGroup':{'value':'gold','priority':2},
                        'categoryList':{'categoryId':2,'orderInCategory':GOLD_PACK_ID},
                        'packContentInfo':{'itemQuantity':12,'goldQuantity':6,
                                           'silverQuantity':0,'bronzeQuantity':0,
                                           'rareQuantity':6,'playersQuantity':6,
                                           'consumableQuantity':4,'clubItemQuantity':2}})
            result=dict(src);result['purchase']=rows+[row]
            return result
        g['_store_purchasegroups']=store
    g['_abea_content_122_installed']=True
    g['log'].info('ABEA 1.2.3 installed; upgrades 3; 10K twelve-item pack ready=%s',ready)
